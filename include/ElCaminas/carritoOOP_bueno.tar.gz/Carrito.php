<?php

namespace ElCaminas;
use \PDO;
use \ElCaminas\Producto;
class Carrito
{
    protected $connect;
    /** Sin parámetros. Sólo crea la variable de sesión
    */
    public function __construct()
    {
        global $connect;
        $this->connect = $connect;
        if (!isset($_SESSION['carrito'])){
            $_SESSION['carrito'] = array();
        }

    }
    public function addItem($id, $cantidad){
        $_SESSION['carrito'][$id] = $cantidad;
    }
    public function deleteItem($id){
      unset($_SESSION['carrito'][$id]);
    }
    public function empty(){
      unset($_SESSION['carrito']);
      self::__construct();
    }
    public function howMany(){
      return count($_SESSION['carrito']);
    }
    public function toHtml(){
      //NO USAR, de momento
      $redirect = "/tienda2/";
      if(isset($_GET['redirect'])){
        $redirect =  $_GET['redirect'];
      }

      $precio_final = 0;
      $str = <<<heredoc
      <table class="table">
        <thead> <tr> <th>#</th> <th>Producto</th> <th>Cantidad</th> <th>Precio</th> <th>Total</th></tr> </thead>
        <tbody>
heredoc;
      if ($this->howMany() > 0){
        $i = 0;
        foreach($_SESSION['carrito'] as $key => $cantidad){
          $producto = new Producto($key);
          $i++;
          $subtotal = $producto->getPrecioReal() * $cantidad;
          $precio_final += $subtotal;
          $subtotalTexto = number_format($subtotal , 2, ',', ' ') ;
          $str .=  "<tr><th scope='row'>$i</th><td><a href='" .  $producto->getUrl() . "'>" . $producto->getNombre() . "</a></td><td>".$producto->getCantidad()."</td><td>" .  $producto->getPrecioReal() ." €</td><td>$subtotalTexto €</td><td><a class='borrar_item' href='./carro.php?action=delete&id=" . $producto->getId() . "'><span class='fa fa-trash-o'></span></a></td></tr>";
        }
      }
      $str .= <<<heredoc
        </tbody>
      </table>
heredoc;
      $str .= "<a class='col-xs-4' href='$redirect'><button type='button' class='btn btn-warning'>Seguir comprando</button></a>";
      $str .= "<a class='col-xs-4' href='#'><button type='button' class='btn btn-success'>Checkout</button></a>";
      $str .= "<p class='col-xs-4 text-info'>Precio final: ".$precio_final." €</p>";

      return $str;
    }
}
